using System;
using System.Threading.Tasks;
using Xunit;

namespace NewHireUnitTesting
{
    public class UnitTest1 : IDisposable, IAsyncLifetime
    {
        public void Dispose()
        {
            // Tear down (called once per test)
        }

        public Task InitializeAsync()
        {
            return Task.CompletedTask;
        }

        public Task DisposeAsync()
        {
            return Task.CompletedTask;
        }

        [Fact]
        [Trait("FullMethod", "SumResult")]
        public void TestSum()
        {
            // Arrange
            int a = 18;
            int b = 24;

            // Act
            var sumRequest = new Sum();
            var response = sumRequest.SumResult(a, b);

            // Positive Assert
            Assert.Equal(42, response);

            // Negative Assert
            Assert.NotEqual(40, response);
        }

        [Theory]
        [InlineData(-1, 0)]
        [InlineData(0, -1)]
        public void TestSumFailsNegativeValues(int a, int b)
        {
            // Act
            var sumRequest = new Sum();
            var ex = Assert.ThrowsAny<ArgumentException>(() => sumRequest.SumResult(a, b));

            Assert.NotNull(ex);
            Assert.Equal($"One of the parameter is negative", ex.Message);
        }
    }
}