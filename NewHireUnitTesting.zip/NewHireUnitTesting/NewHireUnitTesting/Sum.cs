﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewHireUnitTesting
{
    public class Sum
    {
        public int SumResult(int a, int b)
        {
            if(a < 0 || b < 0)
            {
                throw new ArgumentException($"One of the parameter is negative");
            }

            var sum = a + b;
            return sum;
        }
    }
}
